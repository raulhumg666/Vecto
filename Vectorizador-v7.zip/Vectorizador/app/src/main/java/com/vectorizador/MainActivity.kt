package com.vectorizador

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.*
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private val shared = ArrayList<String>()
    private val okTypes = setOf("image/jpeg", "image/png", "image/webp", "image/gif", "image/bmp")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        readIntent(intent)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(r.url)
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                v: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams
            ): Boolean {
                chooser?.onReceiveValue(null)
                chooser = cb
                return try {
                    startActivityForResult(p.createIntent(), 1); true
                } catch (e: Exception) { chooser = null; false }
            }
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
        web.evaluateJavascript("if(window.checkShared)checkShared()", null)
    }

    @Suppress("DEPRECATION")
    private fun readIntent(i: Intent?) {
        if (i == null) return
        val uris: List<Uri> = when (i.action) {
            Intent.ACTION_SEND -> listOfNotNull(i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))
            Intent.ACTION_SEND_MULTIPLE -> i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM) ?: emptyList()
            else -> return
        }
        synchronized(shared) {
            for (u in uris) {
                try {
                    val mime = contentResolver.getType(u) ?: ""
                    if (mime !in okTypes) {
                        shared.add("ERR:No se puede abrir ese formato ($mime). Usa JPG, PNG o WebP.")
                        continue
                    }
                    val bytes = contentResolver.openInputStream(u)!!.use { it.readBytes() }
                    shared.add(mime + "|" + Base64.encodeToString(bytes, Base64.NO_WRAP))
                } catch (e: Exception) {
                    shared.add("ERR:No se pudo leer la imagen compartida.")
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 1) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data))
            chooser = null
        } else super.onActivityResult(req, res, data)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    inner class Bridge {
        private fun store(b64: String, name: String, mime: String): Uri {
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
            contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
            return uri
        }

        private fun toast(t: String) =
            runOnUiThread { Toast.makeText(this@MainActivity, t, Toast.LENGTH_LONG).show() }

        @JavascriptInterface
        fun countShared(): Int = synchronized(shared) { shared.size }

        @JavascriptInterface
        fun takeShared(): String = synchronized(shared) { if (shared.isEmpty()) "" else shared.removeAt(0) }

        @JavascriptInterface
        fun save(b64: String, name: String, mime: String) {
            try { store(b64, name, mime); toast("Guardado en Descargas: $name") }
            catch (e: Exception) { toast("No se pudo guardar el archivo") }
        }

        @JavascriptInterface
        fun share(b64: String, name: String, mime: String) {
            try {
                val uri = store(b64, name, mime)
                val i = Intent(Intent.ACTION_SEND).apply {
                    type = mime
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                runOnUiThread { startActivity(Intent.createChooser(i, "Compartir")) }
            } catch (e: Exception) { toast("No se pudo compartir el archivo") }
        }
    }
}
